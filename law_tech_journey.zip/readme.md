# Law + Tech Journey 🚀

This repository documents my personal journey as I transition into Law from a tech background.

## Structure
- `training/`: Daily legal mentorship notes.
- `blog/`: Essays and opinion pieces.
- `legal/`: RTI drafts, legal notices.
- `templates/`: Notion + GitHub sync templates.

# Notion Tracker Template (Law + Tech Journey)

| Title | GitHub Link | Date Created | Category | Status | Summary / Notes | Last Updated | Notion Link |
|-------|-------------|---------------|----------|--------|------------------|---------------|--------------|
| AI Trap Essay | [GitHub](https://github.com/your-repo/blog/ai-trap.md) | 2025-07-29 | Blog | Draft | On damage of AI to reasoning | 2025-07-29 | [Notion]() |
| Day 1 Notes | [GitHub](https://github.com/your-repo/training/day1-constitution.md) | 2025-07-30 | Training Day | Done | Constitution intro notes | 2025-07-30 | [Notion]() |

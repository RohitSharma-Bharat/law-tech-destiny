# RTI Draft – Electricity Tariff Manipulation

## Applicant: Norul (Citizen of India)
## Department: UPPCL, MNRE

### Information Sought:
1. Basis of change in import/export tariff post PPA.
2. Copy of revised tariff order and public notice, if any.
3. File noting regarding policy changes affecting prosumers.

---
📜 *Template RTI – Drafted on 2025-08-01*
